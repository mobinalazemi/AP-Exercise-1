

public class Main {
    public static void main(String[] args) {

        Student student = new Student();
        Professor professor = new Professor();

        //q6.
        if (professor instanceof Human){
            System.out.println("professor an instance of Human")
        }
        else{
            System.out.println("professor isn't an instance of Human")
        }


        if (student instanceof Human){
            System.out.println("student an instance of Human")
        }
        else{
            System.out.println("Student isn't an instance of Human")
        }

        Human human = new Student("name", "studentNumber", "majorName", "universityName");
        Human human = new Professor("name","numberOfCourse", "Specialty", "faculty");

        //q7.
        human.sayMyName();

        //q8.
        human.sayMyName();
    }
}
